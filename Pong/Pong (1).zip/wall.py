import pygame

class Wall:

	def __init__(self):
		