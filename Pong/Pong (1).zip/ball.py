import pygame

class Ball:
	