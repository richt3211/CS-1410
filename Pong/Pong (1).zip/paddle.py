import pygame

class Paddle:

	def __init__():
		