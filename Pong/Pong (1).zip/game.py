import pygame

def Game:

	def __init__():

		